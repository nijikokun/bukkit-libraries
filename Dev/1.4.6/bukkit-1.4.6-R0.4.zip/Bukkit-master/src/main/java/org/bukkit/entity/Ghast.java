package org.bukkit.entity;

/**
 * Represents a Ghast.
 */
public interface Ghast extends Flying {}
