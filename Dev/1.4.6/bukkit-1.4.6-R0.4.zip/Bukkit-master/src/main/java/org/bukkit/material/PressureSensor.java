package org.bukkit.material;

public interface PressureSensor {
    public boolean isPressed();
}
