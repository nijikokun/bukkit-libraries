package org.bukkit.entity;

/**
 * Represents a Witch
 */
public interface Witch extends Monster {
}
