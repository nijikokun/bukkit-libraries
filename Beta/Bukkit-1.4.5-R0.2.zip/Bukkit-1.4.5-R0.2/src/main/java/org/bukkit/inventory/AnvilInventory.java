package org.bukkit.inventory;

public interface AnvilInventory extends Inventory {
}
