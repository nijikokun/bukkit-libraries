package org.bukkit.entity;

/**
 * Represents an Ender Dragon
 */
public interface EnderDragon extends ComplexLivingEntity {

}
