package org.bukkit.entity;

/**
 * Represents a thrown Experience bottle.
 */
public interface ThrownExpBottle extends Projectile {

}
