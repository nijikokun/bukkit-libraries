package org.bukkit.entity;

/**
 * Represents a Blaze monster
 */
public interface Blaze extends Monster {

}
